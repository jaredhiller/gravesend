<?php get_header(); ?>
			
			<!--BEGIN #primary .hfeed-->
			<div id="primary" class="hfeed">			
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				
				<!--BEGIN .hentry -->
				<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">				
					<h2 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php printf(__('Permanent Link to %s', 'framework'), get_the_title()); ?>"> <?php the_title(); ?></a></h2>
				
					<!--BEGIN .entry-container -->
					<div class="entry-container">
									
				    	<!--BEGIN .entry-meta -->
    					<div class="entry-meta">
    					    <h4><?php _e('Posted', 'framework') ?></h4>
    					    <span><?php the_time( get_option('date_format') ); ?></span>
                        
                            <h4><?php _e('Categories', 'framework'); ?></h4>
                            <span><?php the_category('<br />'); ?></span>
                        
                            <?php the_tags('<h4>' . __('Tags', 'framework') . '</h4><span>', '<br />', '</span>' ); ?>
						
						
    						<h4><?php _e('Comments', 'framework'); ?></h4>
    						<span class="comment-count"><?php comments_popup_link(__('No Comments', 'framework'), __('1 Comment', 'framework'), __('% Comments', 'framework')); ?></span>
						
    						<?php if( is_user_logged_in() ) { echo '<h4>' . __('Edit', 'framework') . '</h4>'; } ?>
    						<?php edit_post_link( __('edit', 'framework'), '<span class="edit-post">[', ']</span>' ); ?>
    					<!--END .entry-meta -->
    					</div>
					
    					<?php /* if the post has a WP 2.9+ Thumbnail */
    					$display_img = get_option('tz_display_featured_img');
    					if ( function_exists('has_post_thumbnail') && has_post_thumbnail() && ($display_img == __('Yes', 'framework')) ) { ?>
    					<div class="post-thumb">
    						<a title="<?php printf(__('Permanent Link to %s', 'framework'), get_the_title()); ?>" href="<?php the_permalink(); ?>"><?php the_post_thumbnail('thumbnail-large'); /* post thumbnail settings configured in functions.php */ ?></a>
    					</div>
    					<?php } ?>

    					<!--BEGIN .entry-content -->
    					<div class="entry-content">
    						<?php the_content(__('Continue Reading', 'framework')); ?>
    					<!--END .entry-content -->
    					</div>
    				
    				<!--END .entry-container -->	
					</div>
                
				<!--END .hentry-->  
				</div>

				<?php endwhile; ?>

			<!--BEGIN .navigation .page-navigation -->
			<div class="navigation page-navigation clearfix">
				<div class="nav-next"><?php next_posts_link(__('&larr; Older Entries', 'framework')) ?></div>
				<div class="nav-previous"><?php previous_posts_link(__('Newer Entries &rarr;', 'framework')) ?></div>
			<!--END .navigation .page-navigation -->
			</div>

			<?php else : ?>

				<!--BEGIN #post-0-->
				<div id="post-0" <?php post_class(); ?>>
				
					<h2 class="entry-title"><?php _e('Error 404 - Not Found', 'framework') ?></h2>
				
					<!--BEGIN .entry-content-->
					<div class="entry-content">
						<p><?php _e("Sorry, but you are looking for something that isn't here.", "framework") ?></p>
					<!--END .entry-content-->
					</div>
				
				<!--END #post-0-->
				</div>

			<?php endif; ?>
			<!--END #primary .hfeed-->
			</div>

<?php get_footer(); ?>